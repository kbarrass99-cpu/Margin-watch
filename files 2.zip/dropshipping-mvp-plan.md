# Dropshipping Software Opportunity: Research, Ranking & MVP Plan

## Part 1 — Research: What actually hurts dropshippers right now

Pulled from current dropshipping communities, seller blogs, and tool-review sites (2026):

1. **Unit economics are invisible until it's too late** — sellers subtract COGS from price and call it "profit," ignoring ad spend, processing fees, refunds, and app subscriptions. This is cited as the #1 cause of stores quietly bleeding cash.
2. **Product/market saturation** — everyone sources the same AliExpress/CJ catalog, so differentiation (not "saturation" per se) is what actually kills stores.
3. **Supplier price & stock volatility** — suppliers change prices or go out of stock without notice; sellers keep selling at the old price or sell items they can no longer fulfill, eating margin or triggering refunds.
4. **Shipping cost & time surprises** — "cheap" products become unprofitable once real shipping is added; long delivery times drive WISMO ("Where Is My Order") tickets and chargebacks.
5. **Customer service overload** — once a store hits 30–50+ orders/day, sellers report spending 4–5 hours/day manually answering repetitive order-status and refund questions.
6. **Customs/compliance friction** — incorrect HS codes and changing de minimis rules are now a top cause of shipment delays on cross-border (China → US/EU) orders.
7. **Returns/refunds/chargeback exposure** — dropshippers can't control product quality but absorb 100% of the customer-facing blame, refund cost, and chargeback risk.
8. **Manual order processing at scale** — pushing orders from Shopify to supplier one-by-one doesn't scale past a few dozen orders/day.
9. **Weak or generic store trust signals** — no trust badges, no real reviews, slow pages, unclear policies — kills conversion rate.
10. **Picking a product blind** — no visibility into how many other stores/ads are already running a product, so sellers can't tell "trending" from "oversaturated."

## Part 2 — 10 problems solvable with *simple* software, ranked

Scored 1 (worst) – 5 (best) for a solo/free-tier builder. **Competition** is reversed (5 = low competition = good for you). **Composite** is a simple average — directional, not scientific.

| # | Problem | Software fix | Competition (5=low) | Demand (5=high) | Ease of dev (5=easy) | Monetization (5=strong) | Composite |
|---|---|---|---|---|---|---|---|
| 1 | Supplier price/stock changes silently erode margin | Watch supplier product URLs, alert on price/stock/variant change | **4** | 4 | 3 | 4 | **3.75** |
| 2 | No visibility into "how saturated is this product" | Ad-library + store-count lookup by product/image | 2 | 4 | 2 | 4 | 3.0 |
| 3 | Repetitive WISMO / order-status customer emails | Auto-classify inbox + templated/branded reply + tracking link | 3 | 5 | 2 | 4 | 3.5 |
| 4 | "True profit" hidden by fees/ads/refunds | Profit & breakeven-ROAS calculator | **1** (extremely saturated, many free) | 4 | 5 | 1 (hard to charge — free everywhere) | 2.2 |
| 5 | Branded order tracking / reducing WISMO volume | Branded tracking page + proactive email/SMS | **1** (AfterShip/17TRACK/TrackingMore dominate) | 5 | 2 | 3 | 2.2 |
| 6 | Winning-product research | Curated feed + trend/saturation scoring | **1** (Ecomhunt, Sell The Trend, Niche Scraper, Dropship Spy…) | 5 | 1 (needs scraped data pipelines) | 3 | 2.0 |
| 7 | Bad/slow store trust signals hurting conversion | One-click "store health" audit (speed, policies, trust badges, missing pages) | 3 | 3 | 4 | 3 | 3.25 |
| 8 | Generic product descriptions | AI listing/description generator from a supplier URL | 2 (Importify, Zendrop, Spocket already bundle this) | 3 | 4 | 2 | 2.75 |
| 9 | Chargeback/dispute evidence prep | Auto-compiled evidence packet (tracking, delivery proof, policy) per dispute | 4 | 2 (infrequent need) | 3 | 3 | 3.0 |
| 10 | HS code / customs errors delaying shipments | Lookup + auto-fill correct HS code by product description | 4 | 2 (niche, mostly larger sellers) | 2 (data accuracy is hard) | 2 | 2.5 |

**Top 3 by composite:** #1 Price/Stock Monitor (3.75) → #3 WISMO Auto-Reply (3.5) → #7 Store Health Audit (3.25)

### Why #1 wins over #3 and #7

- **#3 (WISMO auto-reply)** has the highest raw demand but needs email inbox OAuth (Gmail/Outlook API approval, security review) before you can ship anything — that's weeks of overhead before a free MVP is even usable, and it competes indirectly with helpdesk tools (Gorgias, Re:amaze) that already do this well.
- **#7 (Store audit)** is easy to build but is a "use once, maybe come back in 3 months" tool — hard to turn into recurring revenue, and it overlaps with free tools like Google PageSpeed / Shopify's own theme checks.
- **#1 (Price/Stock Monitor)** is the only one of the three that is: genuinely low-competition (no dedicated standalone free tool for this — it's usually a buried feature inside $30–50/mo all-in-one platforms like DSers/Zendrop), needed *continuously* (not a one-off), simple enough to build with free-tier infrastructure, and naturally recurring-revenue shaped (you keep paying because it keeps watching).

**Chosen problem: Supplier Price & Stock Monitor** — "know the moment your supplier changes price, kills stock, or drops a variant, before it costs you money."

---

## Part 3 — MVP Design: "MarginWatch" (working name)

### Core value proposition
> Paste your supplier product links once. Get an alert the moment the price, stock status, or variant options change — so you never sell at a stale price or oversell a dead item.

### Who it's for
Solo/small Shopify & WooCommerce dropshippers sourcing from AliExpress / CJdropshipping / similar marketplaces, running 5–200 SKUs, with no dedicated ops person watching supplier pages manually.

### MVP scope (v1 — deliberately narrow)

**In scope:**
- Add a supplier product URL (AliExpress to start — biggest addressable base).
- Poll each tracked URL on a schedule (e.g. every 6–12 hours on free tier).
- Detect and store: price, in-stock/out-of-stock status, and variant list (if scrape-able).
- Email alert when price moves beyond a user-set threshold (e.g. >3%), stock goes to zero, or a variant disappears.
- Simple dashboard: list of tracked products, current vs. last-known values, sparkline of price history.
- Manual "check now" button.

**Explicitly out of scope for v1** (cut ruthlessly to ship free):
- Multi-supplier auto-detection (start with URL paste, not a browser extension).
- Shopify/WooCommerce write-back (auto-updating your store price) — v2 feature, and a strong upsell.
- SMS/Slack alerts — v2.
- Team accounts / multi-user — v2.

### User flow
1. Sign up (email + password, or Google OAuth via Supabase Auth — free).
2. Paste up to N AliExpress product URLs (N = 5 on free tier).
3. Backend fetches the page, parses price/stock/variants, stores baseline.
4. Cron job re-checks every 6–12 hours; diffs against last snapshot.
5. On a meaningful change → email via a transactional email API + dashboard flag.
6. User dashboard shows a simple change feed: "Product X: $12.40 → $15.90 (+28%) — 2 hours ago."

### Data model (Postgres via Supabase free tier)

```
users            (id, email, plan, created_at)
tracked_products (id, user_id, source_url, title, image_url, created_at, is_active)
snapshots        (id, tracked_product_id, price, currency, in_stock, variants_json, checked_at)
alerts           (id, tracked_product_id, snapshot_id, type, message, sent_at, read_at)
```

`snapshots` is append-only — this alone gives you a price-history chart for free.

### Architecture (100% free-tier)

| Layer | Choice | Why free |
|---|---|---|
| Frontend | Next.js (React) | Vercel free tier hosting |
| Backend/API | Next.js API routes or a small Node/Express service | Same host, or Render free web service |
| Database | Supabase (Postgres) free tier | 500MB DB, generous for MVP scale |
| Auth | Supabase Auth | Free, built-in |
| Scraping | Node + `cheerio` (static HTML) first; fall back to headless browser (`playwright`) only if AliExpress requires JS rendering | Self-hosted on your own compute, no per-request scraping-API fees |
| Scheduling | Vercel Cron (free tier allows scheduled functions) or GitHub Actions scheduled workflow (free for public/small private repos) | No paid cron service needed |
| Email alerts | Resend or Postmark free tier (~100–3,000 emails/month free) | Enough for MVP volume |
| Monitoring/errors | Sentry free tier | Optional, catch scraper breakage fast |

**Total infra cost at MVP scale: $0/month.** The only real constraint is scrape volume — free-tier compute and polling every 6–12 hrs (not real-time) keeps you well within free limits for the first few hundred users.

### The one hard technical risk — and how to de-risk it
AliExpress pages are JS-heavy and anti-bot measures can change. Mitigations, in order of effort:
1. Start with product pages that expose data in an embedded JSON blob (`window.runParams` or similar) — much more stable than scraping rendered DOM.
2. Rotate a small pool of realistic headers/user-agents; keep polling frequency low (this is not real-time monitoring, so you don't need to hammer the site).
3. If AliExpress blocks you outright, pivot the *first* supported supplier to CJdropshipping (which has a public API) — same product, more reliable data source, and it's an underserved supplier in this specific tool category.
4. Design the scraper as a pluggable "source adapter" from day one, so adding a second supplier later is a new adapter, not a rewrite.

### Monetization plan

- **Free tier:** track up to 5 products, checks every 12 hours, email alerts only.
- **Paid tier (~$9–15/month):** track up to 100 products, checks every hour, price-history export, and (v2) auto-sync the new price to your Shopify listing.
- This mirrors the pricing shape of adjacent tools (AfterShip/17TRACK entry tiers sit at $9–11/month) so it's a familiar price point for this buyer.
- The real expansion revenue is the **v2 auto-price-sync to Shopify** — that turns "alert tool" into "protects your margin automatically," which is a much easier $15–29/month sell once you have trust and usage data.

### Launch plan (free channels)
- Post the free tier directly in r/dropship, r/dropshipping, r/shopify, and dropshipping Discord/Facebook groups — lead with the pain ("I kept selling a product after my supplier raised the price 40% — built a free tool so it never happens again").
- Product Hunt launch once the dashboard is polished.
- Short demo video/GIF showing a real price-hike alert — this is a visual, easy-to-grok problem.
- Cold outreach to a handful of dropshipping YouTubers/TikTokers for a review in exchange for early access — this niche has an active creator economy that reviews new tools.

### Build order (suggested for a solo builder)
1. DB schema + Supabase project (free) — 1 evening.
2. Scraper adapter for AliExpress + snapshot diffing logic — 1–2 days (the core risk, tackle first).
3. Auth + "add tracked product" flow — 1 day.
4. Cron job + email alert sending — half a day.
5. Dashboard UI (list + price history sparkline) — 1–2 days.
6. Deploy (Vercel + Supabase), smoke-test with your own real AliExpress links for a week before public launch.

This is realistically a 1–2 week solo build to a launchable free MVP.
